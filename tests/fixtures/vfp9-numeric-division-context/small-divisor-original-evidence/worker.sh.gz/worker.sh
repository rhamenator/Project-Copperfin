#!/bin/bash
set -u
task_root=/home/rich/.codex/worktrees/numeric-small-divisor-5611/Project-Copperfin
task_build="$task_root/build/small-divisor-original"
task_evidence="$task_root/build/small-divisor-original-attempt2"
cd "$task_root" || exit 70
test ! -e "$task_evidence/start.utc" || exit 73
date -u +%FT%TZ > "$task_evidence/start.utc"
finish() { printf '%s\n' "$1" > "$task_evidence/worker.status"; date -u +%FT%TZ > "$task_evidence/end.utc"; exit "$1"; }
pressure() {
    cat /proc/pressure/io > "$task_evidence/pressure-$1.txt"
    awk '/^full / {split($2,a,"="); split($3,b,"="); exit !(a[2] < 1 && b[2] < 1)}' "$task_evidence/pressure-$1.txt"
}
sha256sum -c "$task_evidence/pre-build.sha256" > "$task_evidence/source-before.log" || finish 74
git diff --exit-code origin/main -- src include > "$task_evidence/production-before.diff" || finish 74
git rev-parse HEAD origin/main HEAD:src origin/main:src HEAD:include origin/main:include > "$task_evidence/revisions.txt"
pressure configure || finish 75
cmake -S "$task_root" -B "$task_build" -G Ninja -DCMAKE_BUILD_TYPE=Debug '-DCMAKE_CXX_FLAGS_DEBUG=-O0 -g0' '-DCMAKE_C_FLAGS_DEBUG=-O0 -g0' > "$task_evidence/configure.log" 2>&1
task_rc=$?; printf '%s\n' "$task_rc" > "$task_evidence/configure.status"
test "$task_rc" -eq 0 || finish "$task_rc"
pressure build || finish 75
cmake --build "$task_build" --parallel 1 --target test_prg_engine_numeric_small_divisor test_prg_engine_numeric_nonwhole_division test_prg_engine_numeric_constant_division test_prg_numeric_nonwhole_division_helper test_prg_numeric_constant_division_intrinsic_helper > "$task_evidence/build.log" 2>&1
task_rc=$?; printf '%s\n' "$task_rc" > "$task_evidence/build.status"
test "$task_rc" -eq 0 || finish "$task_rc"
date -u +%FT%TZ > "$task_evidence/build-end.utc"
sha256sum -c "$task_evidence/pre-build.sha256" > "$task_evidence/source-after-build.log" || finish 74
pressure ctest || finish 75
ctest --test-dir "$task_build" --parallel 1 --output-on-failure --output-junit "$task_evidence/results.xml" -R '^(test_prg_engine_numeric_small_divisor|test_prg_engine_numeric_nonwhole_division|test_prg_engine_numeric_constant_division|test_prg_numeric_nonwhole_division_helper|test_prg_numeric_constant_division_intrinsic_helper|test_native_test_isolation_contract|test_cloud_validation_sanitizer_selection)$' > "$task_evidence/ctest.log" 2>&1
task_rc=$?; printf '%s\n' "$task_rc" > "$task_evidence/ctest.status"
cat /proc/pressure/io > "$task_evidence/pressure-after.txt"
sha256sum -c "$task_evidence/pre-build.sha256" > "$task_evidence/source-after-test.log" || finish 74
git diff --exit-code origin/main -- src include > "$task_evidence/production-after.diff" || finish 74
finish 0
