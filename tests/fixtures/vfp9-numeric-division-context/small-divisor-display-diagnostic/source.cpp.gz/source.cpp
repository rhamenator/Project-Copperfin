// Copyright © 2026 Richard M. Hamilton.
// SPDX-License-Identifier: GPL-3.0-only
// Additional permission: Copperfin Application, Runtime, and Toolchain Exception 1.0; see LICENSE.
#include "copperfin/runtime/prg_engine.h"
#include "fixtures/vfp9-numeric-division-context/small-divisor-public-expected.h"
#include <bit>
#include <filesystem>
#include <iostream>
#include <string>
std::string hex(const std::string& s) {
    std::string out;
    for (const unsigned char c : s) { out += "0123456789ABCDEF"[c/16]; out += "0123456789ABCDEF"[c%16]; }
    return out;
}
int main() {
    using namespace copperfin::runtime;
    const int settings[] = {0,2,6,14,18};
    const auto root = std::filesystem::current_path()/"literal-display-owned";
    if (!std::filesystem::create_directory(root)) return 71;
    unsigned rows=0, differences=0;
    for (const auto mode : {"COPPERFIN","VFP9"}) for (unsigned d=0;d<5;++d) for (unsigned f=0;f<2;++f) {
        RuntimeSessionOptions options;
        options.startup_path=(root/"probe.prg").string(); options.working_directory=root.string();
        options.temp_directory=(root/"runtime-temp").string(); options.require_source_text_overrides=true;
        options.startup_source_text=std::string("SET NUMERICBEHAVIOR TO ")+mode+"\nSET DECIMALS TO "+std::to_string(settings[d])+"\nSET FIXED "+(f?"ON":"OFF")+"\nLOCAL nPause\nnPause=0\nnPause=1\nRETURN\n";
        auto session=PrgRuntimeSession::create(options); session.add_breakpoint({options.startup_path,6});
        if (session.run(DebugResumeAction::continue_run).reason!=DebugPauseReason::breakpoint) return 72;
        for (const auto& r : copperfin::test::native_small_divisor_rows) {
            if (!std::string(r.label).starts_with("literal-control:")) continue;
            const auto n=session.evaluate_watch_expression(r.expression);
            const auto s=session.evaluate_watch_expression(std::string("TRANSFORM(")+r.expression+")");
            if (!n.ok || n.value.kind!=PrgValueKind::number || !s.ok || s.value.kind!=PrgValueKind::string) return 73;
            const bool m=n.value.numeric_metadata==r.metadata[d], b=std::bit_cast<std::uint64_t>(n.value.number_value)==r.bits;
            if (!m || !b) return 74;
            const std::string expected=r.display[d*2+f];
            if (s.value.string_value!=expected) ++differences;
            std::cout<<mode<<'|'<<settings[d]<<'|'<<(f?"ON":"OFF")<<'|'<<r.expression<<'|'<<hex(expected)<<'|'<<hex(s.value.string_value)<<'|'<<m<<'|'<<b<<'\n';
            ++rows;
        }
    }
    std::cout<<"DONE|"<<rows<<"|mismatches="<<differences<<'\n';
    return rows==300&&differences==70?0:1;
}
