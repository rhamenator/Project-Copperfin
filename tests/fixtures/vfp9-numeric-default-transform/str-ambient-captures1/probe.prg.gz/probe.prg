* Copyright © 2026 Richard M. Hamilton.
* SPDX-License-Identifier: GPL-3.0-only
* RQ-CF-PRG-NUMERIC-DEFAULT-TRANSFORM-001: diagnostic ambient settings, not expected strings.
LOCAL ARRAY inputHex[6],targetDecimals[6],sourceIndices[6]
inputHex[1]='3CC1FF130772E184'
targetDecimals[1]=15
sourceIndices[1]=184
inputHex[2]='3CC1FF130772E185'
targetDecimals[2]=15
sourceIndices[2]=185
inputHex[3]='3CC1FF130772E186'
targetDecimals[3]=15
sourceIndices[3]=186
inputHex[4]='BCC1FF130772E184'
targetDecimals[4]=15
sourceIndices[4]=190
inputHex[5]='BCC1FF130772E185'
targetDecimals[5]=15
sourceIndices[5]=191
inputHex[6]='BCC1FF130772E186'
targetDecimals[6]=15
sourceIndices[6]=192
LOCAL ambientNo,ambientD,ambientDecimalType,ambientDecimalHex,ambientFixedType,ambientFixedHex
LOCAL ambientMeta,ambientBits,ambientAfterMeta,ambientAfterBits,ambientAfterDecimalHex,ambientAfterFixedHex
LOCAL outputPath,libraryPath,crtPath,index,decimalCount,fixedNo,fixedMode
LOCAL payload,argumentHex,line,caught,total,failed
LOCAL beforeMeta,beforeBits,beforeDisplay,beforeStr,beforeF,beforeG,afterF,afterG
LOCAL str16Type,str16Hex,str17Type,str17Hex
LOCAL str15AfterType,str15AfterHex,str18AfterType,str18AfterHex
LOCAL str15Type,str15Hex,str18Type,str18Hex,afterMeta,afterBits,afterDisplay,afterStr
outputPath='Z:\home\rich\.codex\worktrees\numeric-literal-display-5611\Project-Copperfin\build\default-transform-str-ambient\results.txt'
libraryPath='Z:\home\rich\dev\Project-Copperfin\build\pr7203-completed\native-evidence\diagnostic\cause-probe.fll'
crtPath='Z:\home\rich\.codex\worktrees\numeric-literal-display-5611\Project-Copperfin\build\default-transform-gcvt-captures1\gcvt-probe.fll'
=STRTOFILE('VERSION|'+VERSION()+CHR(13)+CHR(10),outputPath,0)
TRY
 SET LIBRARY TO (libraryPath) ADDITIVE
 SET LIBRARY TO (crtPath) ADDITIVE
CATCH TO caught
 =STRTOFILE('ERROR-LOAD|'+ALLTRIM(STR(caught.ErrorNo,6,0))+'|'+HexBytes(caught.Message)+CHR(13)+CHR(10),outputPath,1)
 SET LIBRARY TO
 RETURN
ENDTRY
total=0
FOR index=1 TO ALEN(inputHex)
 decimalCount=targetDecimals[index]
 SET DECIMALS TO decimalCount
 argumentHex=inputHex[index]
 payload=CTOBIN(Unhex(argumentHex),'BS')
 FOR fixedNo=1 TO 2
  IF fixedNo=1
   SET FIXED OFF
   fixedMode='OFF'
  ELSE
   SET FIXED ON
   fixedMode='ON'
  ENDIF
  FOR ambientNo=1 TO 3
   ambientD=IIF(ambientNo=1,0,IIF(ambientNo=2,13,18))
   SET DECIMALS TO 15
  failed=.F.
  TRY
   beforeMeta=CFNMETA(CFNDEC(CFNWIDTH(payload,40),18))
   beforeBits=HexBytes(BINTOC(CFNDEC(CFNWIDTH(payload,40),18),'BRS'))
   beforeDisplay=HexBytes(TRANSFORM(CFNDEC(CFNWIDTH(payload,40),18)))
   beforeStr=HexBytes(STR(CFNDEC(CFNWIDTH(payload,40),18),40,decimalCount))
   beforeF=CFNFCVT(CFNDEC(CFNWIDTH(payload,40),18),17)
   IF LEFT(beforeF,6)=='ERROR:'
    failed=.T.
    line='ERROR-F-BEFORE|'+ALLTRIM(STR(index,6,0))+'|'+HexBytes(beforeF)
   ELSE
    beforeG=CFNGCVT(CFNDEC(CFNWIDTH(payload,40),18),17)
    IF LEFT(beforeG,6)=='ERROR:'
     failed=.T.
     line='ERROR-G-BEFORE|'+ALLTRIM(STR(index,6,0))+'|'+HexBytes(beforeG)
    ELSE
     SET DECIMALS TO ambientD
     ambientDecimalType=VARTYPE(SET('DECIMALS'))
     ambientDecimalHex=HexBytes(TRANSFORM(SET('DECIMALS')))
     ambientFixedType=VARTYPE(SET('FIXED'))
     ambientFixedHex=HexBytes(TRANSFORM(SET('FIXED')))
     ambientMeta=CFNMETA(CFNDEC(CFNWIDTH(payload,40),18))
     ambientBits=HexBytes(BINTOC(CFNDEC(CFNWIDTH(payload,40),18),'BRS'))
     str15Type=VARTYPE(STR(CFNDEC(CFNWIDTH(payload,40),18),40,15))
     str15Hex=HexBytes(STR(CFNDEC(CFNWIDTH(payload,40),18),40,15))
     str18Type=VARTYPE(STR(CFNDEC(CFNWIDTH(payload,40),18),40,18))
     str18Hex=HexBytes(STR(CFNDEC(CFNWIDTH(payload,40),18),40,18))
     str16Type=VARTYPE(STR(CFNDEC(CFNWIDTH(payload,40),18),40,16))
     str16Hex=HexBytes(STR(CFNDEC(CFNWIDTH(payload,40),18),40,16))
     str17Type=VARTYPE(STR(CFNDEC(CFNWIDTH(payload,40),18),40,17))
     str17Hex=HexBytes(STR(CFNDEC(CFNWIDTH(payload,40),18),40,17))
     str15AfterType=VARTYPE(STR(CFNDEC(CFNWIDTH(payload,40),18),40,15))
     str15AfterHex=HexBytes(STR(CFNDEC(CFNWIDTH(payload,40),18),40,15))
     str18AfterType=VARTYPE(STR(CFNDEC(CFNWIDTH(payload,40),18),40,18))
     str18AfterHex=HexBytes(STR(CFNDEC(CFNWIDTH(payload,40),18),40,18))
     ambientAfterMeta=CFNMETA(CFNDEC(CFNWIDTH(payload,40),18))
     ambientAfterBits=HexBytes(BINTOC(CFNDEC(CFNWIDTH(payload,40),18),'BRS'))
     ambientAfterDecimalHex=HexBytes(TRANSFORM(SET('DECIMALS')))
     ambientAfterFixedHex=HexBytes(TRANSFORM(SET('FIXED')))
     SET DECIMALS TO 15
     afterMeta=CFNMETA(CFNDEC(CFNWIDTH(payload,40),18))
     afterBits=HexBytes(BINTOC(CFNDEC(CFNWIDTH(payload,40),18),'BRS'))
     afterDisplay=HexBytes(TRANSFORM(CFNDEC(CFNWIDTH(payload,40),18)))
     afterStr=HexBytes(STR(CFNDEC(CFNWIDTH(payload,40),18),40,decimalCount))
     afterF=CFNFCVT(CFNDEC(CFNWIDTH(payload,40),18),17)
     IF LEFT(afterF,6)=='ERROR:'
      failed=.T.
      line='ERROR-F-AFTER|'+ALLTRIM(STR(index,6,0))+'|'+HexBytes(afterF)
     ELSE
      afterG=CFNGCVT(CFNDEC(CFNWIDTH(payload,40),18),17)
      IF LEFT(afterG,6)=='ERROR:'
       failed=.T.
       line='ERROR-G-AFTER|'+ALLTRIM(STR(index,6,0))+'|'+HexBytes(afterG)
      ELSE
       line=fixedMode+'|'+ALLTRIM(STR(index,6,0))+'|'+argumentHex+'|'+ALLTRIM(STR(decimalCount,4,0))+'|'+beforeMeta+'|'+beforeBits+'|'+beforeDisplay+'|'+beforeStr+'|'+VARTYPE(SET('DECIMALS'))+'|'+HexBytes(TRANSFORM(SET('DECIMALS')))+'|'+VARTYPE(SET('FIXED'))+'|'+HexBytes(TRANSFORM(SET('FIXED')))+'|'+beforeF+'|'+beforeG+'|'+str15Type+'|'+str15Hex+'|'+str18Type+'|'+str18Hex+'|'+afterMeta+'|'+afterBits+'|'+afterDisplay+'|'+afterStr+'|'+afterF+'|'+afterG+'|'+str16Type+'|'+str16Hex+'|'+str17Type+'|'+str17Hex+'|'+str15AfterType+'|'+str15AfterHex+'|'+str18AfterType+'|'+str18AfterHex+'|'+ALLTRIM(STR(sourceIndices[index],6,0))+'|'+ALLTRIM(STR(ambientD,4,0))+'|'+ambientDecimalType+'|'+ambientDecimalHex+'|'+ambientFixedType+'|'+ambientFixedHex+'|'+ambientMeta+'|'+ambientBits+'|'+ambientAfterMeta+'|'+ambientAfterBits+'|'+ambientAfterDecimalHex+'|'+ambientAfterFixedHex
      ENDIF
     ENDIF
    ENDIF
   ENDIF
  CATCH TO caught
   failed=.T.
   line='ERROR-'+fixedMode+'|'+ALLTRIM(STR(index,6,0))+'|'+argumentHex+'|'+ALLTRIM(STR(caught.ErrorNo,6,0))+'|'+HexBytes(caught.Message)
  ENDTRY
  =STRTOFILE(line+CHR(13)+CHR(10),outputPath,1)
  IF failed
   SET LIBRARY TO
   RETURN
  ENDIF
  total=total+1
  ENDFOR
 ENDFOR
ENDFOR
=STRTOFILE('DONE|'+ALLTRIM(STR(total,6,0))+CHR(13)+CHR(10),outputPath,1)
SET LIBRARY TO

FUNCTION Unhex
 LPARAMETERS value
 LOCAL result,position,high,low
 result=''
 FOR position=1 TO LEN(value) STEP 2
  high=AT(SUBSTR(value,position,1),'0123456789ABCDEF')-1
  low=AT(SUBSTR(value,position+1,1),'0123456789ABCDEF')-1
  result=result+CHR(high*16+low)
 ENDFOR
 RETURN result

FUNCTION HexBytes
 LPARAMETERS value
 LOCAL result,position,byteValue
 result=''
 FOR position=1 TO LEN(value)
  byteValue=ASC(SUBSTR(value,position,1))
  result=result+SUBSTR('0123456789ABCDEF',INT(byteValue/16)+1,1)+SUBSTR('0123456789ABCDEF',MOD(byteValue,16)+1,1)
 ENDFOR
 RETURN result
