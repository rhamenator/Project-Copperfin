// Copyright © 2026 Richard M. Hamilton.
// SPDX-License-Identifier: GPL-3.0-only
// Additional permission: Copperfin Application, Runtime, and Toolchain Exception 1.0; see LICENSE.
// Offline forensic receipt reader; NOT native execution/REA Evidence.
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),a=require('node:assert/strict'),c=require('node:crypto'),root=process.argv[2];a(root);
const bytes=n=>{const p=path.join(root,n);return fs.existsSync(p)?fs.readFileSync(p):z.gunzipSync(fs.readFileSync(p+'.gz'));},text=n=>bytes(n).toString();
const commit='0d836050f63a342c8cc2f741f81acade31100172';a.equal(text('source-commit.txt'),commit+'\n');a.equal(text('build-source-commit.txt'),commit+'\n');a.equal(bytes('source-status.txt').length,0);a.equal(bytes('build-source-status.txt').length,0);
function full(t){const p=Object.fromEntries(t.split('\n').find(s=>s.startsWith('full ')).split(' ').slice(1).map(s=>s.split('=')));return [+p.avg10,+p.avg60];}
const stages=['host-gnu','check-gnu','host-clang','check-clang','boundary-gnu-build','boundary-gnu-check','boundary-clang-build','boundary-clang-check','import','compile','link'];
for(const s of stages){a.equal(text(s+'.status'),'0\n');a.equal(text(s+'.prefix.status'),'1\n');a.equal(text(s+'.guard.status'),'0\n');a(full(text(s+'.pressure-before.txt')).every(x=>x<1));if(s!=='link')a.equal(bytes(s+'.stderr').length,0);}
a.equal(text('link.stderr'),'rust-lld: warning: ignoring section .debug$S with unrecognized magic 0x2\n'.repeat(4));
for(const n of ['gnu','clang']){a.equal(text('boundary-'+n+'-check.stdout'),'gcvt-boundary checks=115 PASS (stub only)\n');const log=JSON.parse(text('binding-'+n+'.checks.json'));a.equal(log.length,72);for(const e of log){a.equal(e.status,0);a.equal(e.prefixStatus,1);a.equal(e.stderr,'');a(full(e.pressure).every(x=>x<1));}}
for(const line of text('build-inputs.sha256').trim().split('\n')){const [hash,p]=line.split(/  /);if(p.startsWith('tests/fixtures/vfp9-numeric-default-transform/')&&!p.includes('captures1/'))a.equal(c.createHash('sha256').update(bytes('source-'+path.basename(p))).digest('hex'),hash);}
a(text('built.sha256').startsWith('0b1fcd2ba81b95631cb52e6ecd0d4afa721b450a967402f504d1852a49e9e9ac  build/default-transform-gcvt/gcvt-probe.fll\n'));
const started=JSON.parse(text('compiler-shell-start.json'));a.equal(started.session_id,32235);a.equal(JSON.parse(text('compiler-shell-poll2.json')).exit_code,0);
a.equal(text('first.prefix.status'),'1\n');a.equal(text('first.guard.status'),'75\n');a.deepEqual(full(text('first.pressure-before.txt')),[5.24,1.86]);
const shell=JSON.parse(text('native-shell-start.json'));a.equal(shell.exit_code,75);a.equal(shell.output,'');a.equal(shell.session_id,undefined);
for(const n of ['first.status','first.out','first-results.txt','repeat.started.utc','repeat.status','audit.json','finished.utc'])a(!fs.existsSync(path.join(root,n))&&!fs.existsSync(path.join(root,n+'.gz')));
const reuse=JSON.parse(text('reuse-receipt.json'));a.equal(reuse.copied.length,172);a.equal(reuse.copyByteEqual,true);a.equal(reuse.buildReusedNotRecompiled,true);a.equal(reuse.nativePreviouslyInvoked,false);
console.log(JSON.stringify({sourceCommit:commit,buildStagesPassed:11,boundaryStubChecksPerCompiler:115,shaPeChecksPerCompiler:72,compilerWorkerExit:0,nativeWorkerExit:75,firstGuardFullPsi:[5.24,1.86],firstPrefixIdle:true,nativeInvoked:false,repeatInvoked:false,pairedQualified:false,buildReuseByteCompared:172,ordinaryShellNotReaEvidence:true}));
