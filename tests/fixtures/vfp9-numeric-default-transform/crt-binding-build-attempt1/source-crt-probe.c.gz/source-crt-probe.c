/* Copyright © 2026 Richard M. Hamilton.
 * SPDX-License-Identifier: GPL-3.0-only
 * Additional permission: Copperfin Application, Runtime, and Toolchain Exception 1.0; see LICENSE.
 * Native-only RQ-CF-PRG-NUMERIC-DEFAULT-TRANSFORM-001 experiment.
 * Published FLL ABI and documented CRT calls; no VFP implementation linkage.
 * No conversion hypothesis or control-word modification is implemented here.
 */
#include "crt-binding.h"
#pragma pack(push, 1)
typedef struct {
    char type, padding;
    short width;
    unsigned decimals;
    long integer;
    double real;
    unsigned char currency[8];
    unsigned handle, object;
} NumericValue;
typedef struct { short count; NumericValue args[2]; } NumericParameters;
/* The packed table stores a code address; type it as the actual fastcall
 * handler rather than casting through the SDK's historical generic pointer. */
typedef void (__fastcall *PublicFunction)(NumericParameters *);
typedef struct { char *name; PublicFunction function; short count; char *types; } PublicInfo;
typedef struct PublicTable { struct PublicTable *next; short count; PublicInfo *info; } PublicTable;
#pragma pack(pop)
_Static_assert(sizeof(long)==4 && sizeof(void *)==4, "32-bit FLL only");
_Static_assert(sizeof(NumericValue)==36 && __builtin_offsetof(NumericValue,real)==12,
               "published byte-packed Value layout");
_Static_assert(sizeof(PublicInfo)==14 && __builtin_offsetof(PublicInfo,function)==4,
               "published packed dispatch address layout");
extern void __fastcall _RetChar(char *);
__declspec(dllimport) void * __stdcall GetModuleHandleA(const char *);
__declspec(dllimport) unsigned long __stdcall GetModuleFileNameA(void *,char *,unsigned long);
__declspec(dllimport) void * __stdcall GetProcAddress(void *,const char *);
__declspec(dllimport) void * __stdcall CreateFileA(const char *,unsigned long,unsigned long,void *,unsigned long,unsigned long,void *);
__declspec(dllimport) int __stdcall GetFileSizeEx(void *,long long *);
__declspec(dllimport) int __stdcall ReadFile(void *,void *,unsigned long,unsigned long *,void *);
__declspec(dllimport) int __stdcall CloseHandle(void *);
typedef struct { void *base,*allocation; unsigned long allocation_protect,region_size,state,protect,type; } MemoryInfo;
_Static_assert(sizeof(MemoryInfo)==28,"32-bit MEMORY_BASIC_INFORMATION");
__declspec(dllimport) unsigned long __stdcall VirtualQuery(const void *,MemoryInfo *,unsigned long);
typedef char * (__cdecl *ConvertFunction)(double,int,int *,int *);
int _fltused=0;

static void *bound_module;
static char bound_path[260];
static CrtPe bound_pe;
static unsigned bound_size;
static unsigned char bound_digest[32];
static int loaded_pe(void *module,CrtPe *pe) {
    MemoryInfo info;
    if(VirtualQuery(module,&info,sizeof(info))!=sizeof(info) || info.base!=module || info.allocation!=module || info.type!=0x1000000 ||
       info.state!=0x1000 || info.region_size<4096 || (info.protect&0x100) ||
       !(info.protect&(0x02|0x04|0x08|0x20|0x40|0x80))) return 0;
    return crt_pe((const unsigned char *)module,4096,pe);
}
/* Hash once per FLL lifetime through the exact runtime-reported path, in THIS
 * 32-bit process. Later calls recheck loaded headers/module/path. This is not
 * an atomic proof of mapped image content or a rehash on every conversion. */
static int bind_module(void *module,const char *path,unsigned length) {
    CrtPe image,file_pe;
    if(!loaded_pe(module,&image)) return 0;
    if(bound_module) {
        if(module!=bound_module || !crt_pe_equal(&image,&bound_pe)) return 0;
        for(unsigned i=0;i<=length;++i) if(path[i]!=bound_path[i]) return 0;
        return 1;
    }
    if(!crt_sha_selftest()) return 0;
    void *file=CreateFileA(path,0x80000000u,1,0,3,0x80,0);
    if(file==(void *)-1) return 0;
    long long size=0;
    int valid=GetFileSizeEx(file,&size) && size>=4096 && size<=8388608;
    CrtSha sha;unsigned total=0,header_used=0,iterations=0;
    /* VFP invokes these synchronous handlers on its evaluation thread. Static
     * scratch avoids a large freestanding32-bit stack-probe dependency. */
    static unsigned char block[4096],header[4096];crt_sha_init(&sha);
    while(valid && total<(unsigned)size) {
        unsigned request=(unsigned)size-total;if(request>sizeof(block)) request=sizeof(block);
        unsigned long got=0;
        if(++iterations>4096 || !ReadFile(file,block,request,&got,0) || !got || got>request) { valid=0;break; }
        for(unsigned i=0;i<got && header_used<sizeof(header);++i) header[header_used++]=block[i];
        crt_sha_update(&sha,block,got);total+=got;
    }
    unsigned long extra=0;
    if(valid && (!ReadFile(file,block,1,&extra,0) || extra)) valid=0;
    if(!CloseHandle(file)) valid=0;
    if(!valid || total!=(unsigned)size || !crt_pe(header,header_used,&file_pe) || !crt_pe_equal(&image,&file_pe)) return 0;
    crt_sha_final(&sha,bound_digest);
    for(unsigned i=0;i<=length;++i) bound_path[i]=path[i];
    bound_pe=image;bound_size=total;bound_module=module;return 1;
}

static char *text(char *out,const char *in) { while(*in) *out++=*in++; return out; }
static char *hex(char *out,unsigned value,unsigned count) {
    static const char digits[]="0123456789ABCDEF";
    while(count) { --count; *out++=digits[(value>>(4*count))&15]; }
    return out;
}
static unsigned control_word(void) {
    unsigned short value; __asm__ __volatile__("fnstcw %0":"=m"(value)); return value;
}
static int numeric(const NumericValue *v,double *out) {
    if(v->type=='I') { *out=(double)v->integer; return 1; }
    if(v->type!='N') return 0;
    for(unsigned i=0;i<8;++i) ((unsigned char *)out)[i]=((const unsigned char *)&v->real)[i];
    return 1;
}
static void convert(NumericParameters *p,int significant) {
    union { double value; unsigned char bytes[8]; } input;
    double count_value;
    if(p->count!=2 || !numeric(&p->args[0],&input.value) || !numeric(&p->args[1],&count_value)) {
        _RetChar("ERROR:PARAMETER"); return;
    }
    /* Reject nonfinite payload before the CRT. Bounded finite count before cast. */
    if((input.bytes[7]&0x7f)==0x7f && (input.bytes[6]&0xf0)==0xf0) {
        _RetChar("ERROR:NONFINITE"); return;
    }
    if(!(count_value>=1 && count_value<=18)) { _RetChar("ERROR:COUNT"); return; }
    int count=(int)count_value;
    if((double)count!=count_value || (significant && count!=15 && count!=16 && count!=17)) {
        _RetChar("ERROR:COUNT"); return;
    }
    /* Query the module already loaded by VFP, never load/replace a DLL. */
    void *module=GetModuleHandleA("msvcr71.dll");
    if(!module) { _RetChar("ERROR:MODULE"); return; }
    char module_path[260];
    unsigned long length=GetModuleFileNameA(module,module_path,sizeof(module_path));
    if(!length || length>=sizeof(module_path)) { _RetChar("ERROR:MODULEPATH"); return; }
    module_path[length]=0;
    if(!bind_module(module,module_path,length)) { _RetChar("ERROR:MODULEBINDING"); return; }
    ConvertFunction function=(ConvertFunction)GetProcAddress(module,significant?"_ecvt":"_fcvt");
    if(!function) { _RetChar("ERROR:EXPORT"); return; }
    int decimal=0,sign=0;
    unsigned before=control_word();
    const char *result=function(input.value,count,&decimal,&sign);
    unsigned after=control_word();
    if(!result) { _RetChar("ERROR:NULL"); return; }
    /* Copy the shared CRT buffer immediately, before any other CRT/FLL call. */
    char digits[128]; unsigned used=0;
    for(;used<sizeof(digits);++used) {
        char c=result[used];
        if(!c) { digits[used]=0; break; }
        if(c<'0' || c>'9') { _RetChar("ERROR:DIGIT"); return; }
        digits[used]=c;
    }
    if(used==sizeof(digits)) { _RetChar("ERROR:BUFFERBOUND"); return; }
    /* Maximum: 518 module hex +254 digit hex + identity/fixed fields <1536. */
    char output[1536],*out=output;
    out=text(out,significant?"kind=E;count=":"kind=F;count=");
    out=hex(out,(unsigned)count,8);
    out=text(out,";real="); for(int i=7;i>=0;--i) out=hex(out,input.bytes[i],2);
    out=text(out,";decimal="); out=hex(out,(unsigned)decimal,8);
    out=text(out,";sign="); out=hex(out,(unsigned)sign,8);
    out=text(out,";cw0="); out=hex(out,before,4);
    out=text(out,";cw1="); out=hex(out,after,4);
    out=text(out,";module="); for(unsigned i=0;i<length;++i) out=hex(out,(unsigned char)module_path[i],2);
    out=text(out,";fileSample=ONCE;fileSize=");out=hex(out,bound_size,8);
    out=text(out,";fileSha256=");for(unsigned i=0;i<32;++i) out=hex(out,bound_digest[i],2);
    out=text(out,";machine=");out=hex(out,bound_pe.machine,4);
    out=text(out,";magic=");out=hex(out,bound_pe.magic,4);
    out=text(out,";stamp=");out=hex(out,bound_pe.stamp,8);
    out=text(out,";imageSize=");out=hex(out,bound_pe.image_size,8);
    out=text(out,";checksum=");out=hex(out,bound_pe.checksum,8);
    out=text(out,";digits="); for(unsigned i=0;i<used;++i) out=hex(out,(unsigned char)digits[i],2);
    *out=0; _RetChar(output);
}
static void __fastcall fixed_conversion(NumericParameters *p) { convert(p,0); }
static void __fastcall significant_conversion(NumericParameters *p) { convert(p,1); }
static PublicInfo functions[]={
    {"CFNFCVT",fixed_conversion,2,"NN"},
    {"CFNECVT",significant_conversion,2,"NN"}
};
__declspec(dllexport) PublicTable _FoxTable={0,2,functions};
/* Same first-party entry pattern as cause-probe.c; installed SDK stays host-only. */
typedef void (*Initializer)(void);
#pragma section(".CRT$XCA",read)
#pragma section(".CRT$XCZ",read)
__declspec(allocate(".CRT$XCA")) Initializer initialize_begin[]={0};
__declspec(allocate(".CRT$XCZ")) Initializer initialize_end[]={0};
extern int __stdcall DllMain(void *,unsigned,void *);
int __stdcall CrtEntry(void *module,unsigned reason,void *reserved) {
    if(reason==1) for(Initializer *p=initialize_begin+1;p<initialize_end;++p) if(*p) (*p)();
    return DllMain(module,reason,reserved);
}
