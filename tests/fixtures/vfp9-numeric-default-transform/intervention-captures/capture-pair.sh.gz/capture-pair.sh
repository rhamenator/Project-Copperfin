#!/bin/bash
set -u
cd /home/rich/.codex/worktrees/numeric-literal-display-5611/Project-Copperfin || exit 90
capture_root=build/default-transform-intervention2
date -u +%FT%TZ > "$capture_root/started.utc"
git rev-parse HEAD > "$capture_root/source-commit.txt"
git status --short > "$capture_root/source-status.txt"
sha256sum tests/fixtures/vfp9-numeric-default-transform/{emit-intervention.cjs,intervention.prg,intervention-cases.json,audit-intervention.cjs,recovery.md} /home/rich/bin/vfp9-probe /home/rich/copperfin-wine-vfp9/drive_c/hotfix968409/vfp9.exe /home/rich/dev/Project-Copperfin/build/pr7203-completed/native-evidence/diagnostic/cause-probe.fll > "$capture_root/inputs.sha256" || exit 91
cp tests/fixtures/vfp9-numeric-default-transform/intervention.prg "$capture_root/probe.prg" || exit 92
cmp tests/fixtures/vfp9-numeric-default-transform/intervention.prg "$capture_root/probe.prg" || exit 93
for capture_name in first repeat; do
 date -u +%FT%TZ > "$capture_root/$capture_name.started.utc"
 pgrep -a -x 'wine|wine64|wine-preloader|wineserver|wineserver64|vfp9.exe' > "$capture_root/$capture_name.prefix-processes.txt"
 prefix_status=$?
 printf '%s\n' "$prefix_status" > "$capture_root/$capture_name.prefix-check.status"
 if [ "$prefix_status" -ne 1 ]; then
  printf '%s\n' 'Existing or unverified Wine process: no native invocation.'
  exit 76
 fi
 cat /proc/pressure/io > "$capture_root/$capture_name.pressure-before.txt"
 awk '$1=="full" {split($2,a,"=");split($3,b,"=");found=1;if(a[2]>=1||b[2]>=1)exit 75} END {if(!found)exit 75}' "$capture_root/$capture_name.pressure-before.txt"
 guard_status=$?
 printf '%s\n' "$guard_status" > "$capture_root/$capture_name.pressure-guard.status"
 if [ "$guard_status" -ne 0 ]; then
  printf '%s\n' 'I/O pressure guard: no native invocation.'
  exit 75
 fi
 nice -n 10 /home/rich/bin/vfp9-probe "$capture_root/probe.prg" --result "$capture_root/results.txt" > "$capture_root/$capture_name.out" 2> "$capture_root/$capture_name.stderr"
 native_status=$?
 printf '%s\n' "$native_status" > "$capture_root/$capture_name.status"
 if [ -f "$capture_root/results.txt" ]; then cp "$capture_root/results.txt" "$capture_root/$capture_name-results.txt"; fi
 cat /proc/pressure/io > "$capture_root/$capture_name.pressure-after.txt"
 date -u +%FT%TZ > "$capture_root/$capture_name.finished.utc"
 printf '%s native status=%s\n' "$capture_name" "$native_status"
 if [ "$native_status" -ne 0 ]; then exit "$native_status"; fi
 sha256sum -c "$capture_root/inputs.sha256" > "$capture_root/$capture_name.inputs-check.txt" 2>&1
 hash_status=$?
 printf '%s\n' "$hash_status" > "$capture_root/$capture_name.inputs-check.status"
 if [ "$hash_status" -ne 0 ]; then exit 94; fi
 if [ "$capture_name" = first ]; then
  node tests/fixtures/vfp9-numeric-default-transform/audit-intervention.cjs "$capture_root" --single > "$capture_root/first-structure.json" 2> "$capture_root/first-structure.stderr"
  structure_status=$?
  printf '%s\n' "$structure_status" > "$capture_root/first-structure.status"
  if [ "$structure_status" -ne 0 ]; then exit "$structure_status"; fi
 fi
done
node tests/fixtures/vfp9-numeric-default-transform/audit-intervention.cjs "$capture_root" > "$capture_root/audit.json" 2> "$capture_root/audit.stderr"
audit_status=$?
printf '%s\n' "$audit_status" > "$capture_root/audit.status"
date -u +%FT%TZ > "$capture_root/finished.utc"
printf 'paired audit status=%s\n' "$audit_status"
exit "$audit_status"
